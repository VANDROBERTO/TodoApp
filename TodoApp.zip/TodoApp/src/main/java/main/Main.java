/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import controller.ProjectController;
import controller.TaskController;
import java.util.Date;
import java.util.List;
import model.Project;
import model.Task;

/**
 *
 * @author Vanderlei
 */
public class Main {
    
    public static void main(String[] args) {
    ProjectController projectController = new ProjectController();
        
        Project project = new Project();
        project.setId(3);
        project.setName("Vand normadProjeto");
        project.setDescription("Super Descrição");
        projectController.save(project);
        
       
        projectController.update(project);
        
        List<Project> projetos = projectController.getAll();
        System.out.println("Total de projetos " + projetos.size());      
        
        projectController.removeById(3);
        
        TaskController tarefa = new TaskController();
        Task task = new Task();
        task.setIdProject(2);
        task.setName("vamos la ");
        task.setDescription("que bosta");
        task.setNotes("padaria");
        task.setCompleted(false);
        task.setDeadline(new Date());
        
        tarefa.save(task);
}
}
